**Associate an existing API key with a Usage Plan**

Command::

  aws apigateway create-usage-plan-key --usage-plan-id a1b2c3 --key-type "API_KEY" --key-id 4vq3yryqm5
